package seedu.addressbook.commands;

public class ViewAllCommandTest {
    // ViewAllCommand is tested together with ViewCommand in ViewCommandTest.
    // This is because they function similarly but ViewCommand hides private information.
    // They are tested with same test data input.
}
